<html>
  <head>
    <title>RPG</title>
    <link rel="stylesheet" href="style.css">

  </head>
<body>
  <div id="topo">
    <!-- foto do topo junto com o link pro index -->
  </div>
    <h1 id="titlepage">Bem Vindo a página do RPG</h1>
  <div id="conteudo">
    
      <p id="text"> Bem vindo(a), você acabou de acessar o site de um estudante do curso Técnico em Informática com um gosto moderadamente ruim.</p>
<hr>
      <p>Hoje irei te colocar no mundo do meu RPG, que se passa e uma ilha devastada por monstros, e tu vai ser o fodão, ou se tu estiver jogando em grupo, vocês vão ser tipo os Avengers, ou alguma referencia de filme de nerd.</p>
      <p>Antes que tu/vocês comece a fazer esclhas questionaveis, deixar o mestre com raiva de vocês e por ultimo matar alguém importante da história tirando 1 no D20, eu vou pedir que crie sua ficha de personagem, só não pode colocar o teu nome de personagem de lol e muito menos do Naruto.<br>
      To falando contigo Sasuke.</p>
  </div>

  <a href="form.php" class="button" id="button">Formulario</a>

</body>


</html>