<?php

    if( isset($_SESSION["sessao"])){
        $arrayProdutos = $_SESSION["sessao"];
     } else{
        $arrayProdutos =  array();

    }

    if( $_SERVER["REQUEST_METHOD"] == "POST"){

        $nome = $_POST["nome"];

        $nome2 = $_POST["nome2"];

        array_push($arrayProdutos, $nome);
        array_push($arrayProdutos, $nome2);

        $_SESSION["sessao"] = $arrayProdutos;


        foreach($arrayProdutos as $value){

            echo "<li>". $value. "</li>";

        }

    }

?>